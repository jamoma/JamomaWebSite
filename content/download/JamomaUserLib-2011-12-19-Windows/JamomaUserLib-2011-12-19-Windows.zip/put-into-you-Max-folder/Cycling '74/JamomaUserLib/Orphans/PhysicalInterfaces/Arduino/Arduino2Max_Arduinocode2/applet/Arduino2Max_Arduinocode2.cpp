#include "WProgram.h"
void sendValue(int x);
/*  
 *  Arduino2Max
 *  Send pin values from Arduino to MAX/MSP
 *  
 *  Arduino2Max.pde
 *  ------------  
 *  Latest update: February 10 2007
 *  ------------
 *  Copyleft: use as you like
 *  by djmatic 
 *  Based on a sketch and patch by Thomas Ouellet Fredericks  tof.danslchamp.org
 *  
 */


int x = 0;                             // a place to hold pin values

void setup()
{
  Serial.begin(115200);                // 115200 is the default Arduino Bluetooth speed
}


void loop()
{ 

if (Serial.available() != -1){         // Check serial buffer for characters
        
    if (Serial.read() == 'r') {       // If an 'r' is received then read the pins
    
for (int pin= 0; pin<=5; pin++){      // Read and send analog pins 0-5
    x = analogRead(pin);
    sendValue (x);
    }

for (int pin= 2; pin<=13; pin++){     // Read and send digital pins 2-13
    x = digitalRead(pin);
    sendValue (x);
    }
  
    Serial.println();                 // Send a carriage returnt to mark end of pin data. 
    delay (5);                        // add a delay to prevent crashing/overloading of the serial port
  
  }

 }
}

void sendValue (int x){              // function to send the pin value followed by a "space". 
 Serial.print(x);
 Serial.print(32, BYTE); 
}



