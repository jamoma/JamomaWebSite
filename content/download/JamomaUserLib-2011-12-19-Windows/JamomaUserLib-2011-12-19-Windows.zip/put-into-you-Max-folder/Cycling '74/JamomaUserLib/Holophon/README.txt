This folder contains GMEM's Holo-edit and communication modules from/to Jamoma.
See also the subfolder with examplepatches.