This user lib is a collection of Jamoma modules and components using Ircam Spatialisateur for MaxMSP.




ABOUT SPATIALISATEUR

Spatialisateur is a software suite for the spatialization of sound signals in real-time intended for musical creation, postproduction, and live performances. Ircam Spatialisateur is available as part of Ircam forum subscription. More information can be found here:

http://forumnet.ircam.fr/692.html?&L=1




VERSION REQUIREMENTS:

This version requires Spat 4.2.5 or newer.



BUG REPORTS AND FEATURE REQUESTS

Please report bugs and requests here:

http://redmine.jamoma.org/projects/ircam-spat