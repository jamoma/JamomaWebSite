BLUE YETI JAMOMA MODULES V 0.1 beta
� Jean-Michel Couturier, Blue Yeti

DESCRIPTION:

Blue Yeti modules are a collection of modules that I use in my interactive programs. These modules are about physics (using Box2D), file utilities and openGL. Other modules will come soon.


SOFTWARE REQUIREMENTS:

You will need Max/Msp 5 and Jamoma 0.5.2 to use this patches.
Modules are at beta stage so some things might occasionally blow up! Feel free to send suggestions and bug reports (you can send me an email to jmc at blueyeti dot fr).


INSTALLATION NOTES:

Unzip and place all files somewhere in max/msp search path.

Dependencies: 
- Jasch objects (http://www.jasch.ch/dl/)
- Box2D (http://charles.bascou.free.fr/box2d/).

