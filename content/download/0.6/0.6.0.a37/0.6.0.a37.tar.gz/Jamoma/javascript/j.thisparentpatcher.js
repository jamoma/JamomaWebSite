
var task = new Task(init, this);
task.schedule(100);



function init()
{
	
	outlet(0, filename);
}