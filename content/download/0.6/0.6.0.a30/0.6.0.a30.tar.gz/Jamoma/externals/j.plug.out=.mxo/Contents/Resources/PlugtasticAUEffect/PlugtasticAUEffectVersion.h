#ifndef __PlugtasticAUEffectVersion_h__
#define __PlugtasticAUEffectVersion_h__


#define kPlugtasticAUEffectVersion			0x00010000
#define PlugtasticAUEffect_COMP_SUBTYPE		'ftmp'
#define PlugtasticAUEffect_COMP_MANF		'74Ob'


#endif // __PlugtasticAUEffectVersion_h__
