
#ifndef __PlugtasticAUInstrumentVersion_h__
#define __PlugtasticAUInstrumentVersion_h__


#ifdef DEBUG
#define kPlugtasticAUInstrumentVersion 0xFFFFFFFF
#else
#define kPlugtasticAUInstrumentVersion 0x00010000	
#endif

#define PlugtasticAUEffect_COMP_SUBTYPE		'ftmp'
#define PlugtasticAUEffect_COMP_MANF		'74Ob'

#endif
